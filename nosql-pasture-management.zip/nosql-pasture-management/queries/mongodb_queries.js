// =============================================================================
// MONGODB QUERIES - Pasture Management System
// =============================================================================

// -------------------------------------------------------------------------
// 1. Basic CRUD Operations
// -------------------------------------------------------------------------

// Find a specific field by ID
db.fields.findOne({ "field_id": "field_001" })

// Find all fields for a farm
db.fields.find({ "farm_id": "farm_001" })

// Find fields with specific soil type
db.fields.find({ "soil_type": "loam" })

// -------------------------------------------------------------------------
// 2. Geospatial Queries - Using 2dsphere index
// -------------------------------------------------------------------------

// Find fields within 5km of a point (weather station location)
db.fields.aggregate([
    {
        $geoNear: {
            near: {
                type: "Point",
                coordinates: [-89.4012, 43.0731]  // [longitude, latitude]
            },
            distanceField: "distance_m",
            maxDistance: 5000,  // 5km in meters
            spherical: true
        }
    },
    {
        $project: {
            field_id: 1,
            name: 1,
            distance_m: 1,
            soil_type: 1,
            "terrain.slope_pct": 1
        }
    },
    {
        $sort: { distance_m: 1 }
    }
])

// Find fields that intersect with a polygon region
db.fields.find({
    boundary: {
        $geoIntersects: {
            $geometry: {
                type: "Polygon",
                coordinates: [[
                    [-89.5, 43.0],
                    [-89.3, 43.0],
                    [-89.3, 43.2],
                    [-89.5, 43.2],
                    [-89.5, 43.0]
                ]]
            }
        }
    }
})

// Find weather stations near a field
db.weather_stations.find({
    location: {
        $near: {
            $geometry: {
                type: "Point",
                coordinates: [-89.4012, 43.0731]
            },
            $maxDistance: 10000  // 10km
        }
    }
})

// -------------------------------------------------------------------------
// 3. Risk Analysis Queries
// -------------------------------------------------------------------------

// Find fields at risk: low NDVI + low moisture
db.fields.find({
    $and: [
        { "latest_metrics.ndvi": { $lt: 0.5 } },
        { "latest_metrics.soil_moisture": { $lt: 20 } }
    ]
}).project({
    field_id: 1,
    name: 1,
    farm_id: 1,
    "latest_metrics.ndvi": 1,
    "latest_metrics.soil_moisture": 1
})

// Find fields with multiple risk factors
db.fields.find({
    $and: [
        { "latest_metrics.ndvi": { $lt: 0.5 } },
        { "latest_metrics.soil_moisture": { $lt: 20 } },
        { $or: [
            { "terrain.slope_pct": { $gt: 8 } },
            { "latest_metrics.temperature_c": { $gt: 28 } }
        ]}
    ]
}).project({
    field_id: 1,
    name: 1,
    farm_id: 1,
    latest_metrics: 1,
    terrain: 1
})

// -------------------------------------------------------------------------
// 4. Treatment History Queries
// -------------------------------------------------------------------------

// Get treatment history for a field, sorted by date
db.treatment_events.find({
    "field_id": "field_001"
}).sort({ "applied_date": -1 }).limit(10)

// Find all irrigation events in the last 30 days
db.treatment_events.find({
    "treatment_type": "irrigation",
    "applied_date": { $gte: new Date(Date.now() - 30*24*60*60*1000) }
})

// Count treatments by type for a farm
db.treatment_events.aggregate([
    { $match: { "farm_id": "farm_001" } },
    { $group: {
        _id: "$treatment_type",
        count: { $sum: 1 },
        total_cost: { $sum: "$cost_usd" },
        avg_cost: { $avg: "$cost_usd" }
    }},
    { $sort: { count: -1 } }
])

// Find fields that haven't been fertilized in 90 days
db.fields.aggregate([
    {
        $lookup: {
            from: "treatment_events",
            let: { fid: "$field_id" },
            pipeline: [
                { $match: {
                    $expr: { $eq: ["$field_id", "$$fid"] },
                    "treatment_type": "fertilizer",
                    "applied_date": { $gte: new Date(Date.now() - 90*24*60*60*1000) }
                }}
            ],
            as: "recent_fertilizer"
        }
    },
    { $match: { "recent_fertilizer": { $size: 0 } } },
    { $project: { field_id: 1, name: 1, farm_id: 1 } }
])

// -------------------------------------------------------------------------
// 5. Aggregation Queries - Summary Statistics
// -------------------------------------------------------------------------

// Summary statistics by soil type
db.fields.aggregate([
    { $group: {
        _id: "$soil_type",
        count: { $sum: 1 },
        avg_area: { $avg: "$area_ha" },
        total_area: { $sum: "$area_ha" },
        avg_ndvi: { $avg: "$latest_metrics.ndvi" },
        avg_moisture: { $avg: "$latest_metrics.soil_moisture" }
    }},
    { $sort: { count: -1 } }
])

// Summary by slope category
db.fields.aggregate([
    { $addFields: {
        slope_category: {
            $switch: {
                branches: [
                    { case: { $lte: ["$terrain.slope_pct", 3] }, then: "flat" },
                    { case: { $lte: ["$terrain.slope_pct", 8] }, then: "gentle" },
                    { case: { $lte: ["$terrain.slope_pct", 15] }, then: "moderate" }
                ],
                default: "steep"
            }
        }
    }},
    { $group: {
        _id: "$slope_category",
        count: { $sum: 1 },
        avg_ndvi: { $avg: "$latest_metrics.ndvi" },
        avg_moisture: { $avg: "$latest_metrics.soil_moisture" }
    }},
    { $sort: { avg_ndvi: 1 } }
])

// Grazing intensity analysis
db.grazing_events.aggregate([
    { $group: {
        _id: "$field_id",
        total_grazing_days: {
            $sum: {
                $divide: [
                    { $subtract: ["$end_date", "$start_date"] },
                    86400000  // milliseconds per day
                ]
            }
        },
        avg_stocking_rate: { $avg: "$stocking_rate" },
        avg_utilization: { $avg: "$utilization_pct" },
        grazing_events: { $sum: 1 }
    }},
    { $sort: { avg_utilization: -1 } }
])

// -------------------------------------------------------------------------
// 6. Farm Dashboard Queries
// -------------------------------------------------------------------------

// Get farm overview with field count and total area
db.farms.aggregate([
    {
        $lookup: {
            from: "fields",
            localField: "farm_id",
            foreignField: "farm_id",
            as: "farm_fields"
        }
    },
    {
        $project: {
            farm_id: 1,
            name: 1,
            "owner.name": 1,
            field_count: { $size: "$farm_fields" },
            total_field_area: { $sum: "$farm_fields.area_ha" },
            avg_ndvi: { $avg: "$farm_fields.latest_metrics.ndvi" },
            avg_moisture: { $avg: "$farm_fields.latest_metrics.soil_moisture" }
        }
    }
])

// -------------------------------------------------------------------------
// 7. Text Search
// -------------------------------------------------------------------------

// Search field notes for specific keywords
db.fields.find({
    $text: { $search: "drainage reseeded" }
}).project({
    field_id: 1,
    name: 1,
    notes: 1,
    score: { $meta: "textScore" }
}).sort({ score: { $meta: "textScore" } })

// -------------------------------------------------------------------------
// Expected Output Examples
// -------------------------------------------------------------------------

/*
Query: Fields within 5km
[
  {
    field_id: "field_001",
    name: "North Pasture",
    distance_m: 1250.45,
    soil_type: "loam",
    terrain: { slope_pct: 3.5 }
  },
  {
    field_id: "field_002",
    name: "East Meadow",
    distance_m: 2100.82,
    soil_type: "sandy_loam",
    terrain: { slope_pct: 8.2 }
  }
]

Query: Treatment summary by type
[
  { _id: "fertilizer", count: 45, total_cost: 5625.50, avg_cost: 125.01 },
  { _id: "irrigation", count: 28, total_cost: 1120.00, avg_cost: 40.00 },
  { _id: "lime", count: 12, total_cost: 3600.00, avg_cost: 300.00 },
  { _id: "mowing", count: 10, total_cost: 500.00, avg_cost: 50.00 }
]
*/

#!/usr/bin/env python3
"""
Redis Aggregation Script for Pasture Management System

Computes rolling metrics from Cassandra data and stores in Redis.
Manages real-time alerts, caching, and pub/sub messaging.

Demonstrates:
- Hashes for latest metrics
- Streams for alert events
- Sorted sets for scheduling
- Pub/Sub for notifications
- TTL policies
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from collections import defaultdict

# =============================================================================
# Configuration
# =============================================================================

REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
DATA_DIR = os.getenv("DATA_DIR", "data")

# TTL configurations (in seconds)
TTL_LATEST_METRICS = 900       # 15 minutes
TTL_ROLLING_AGGREGATES = 3600  # 1 hour
TTL_CACHE = 300                # 5 minutes
TTL_RISK_SETS = 1800           # 30 minutes

# Alert thresholds
THRESHOLDS = {
    "soil_moisture_low": 15.0,
    "soil_moisture_critical": 10.0,
    "ndvi_low": 0.4,
    "ndvi_critical": 0.3,
    "temperature_high": 35.0,
    "grass_height_low": 5.0,
}

# =============================================================================
# Redis Client Class
# =============================================================================

class RedisAggregator:
    """
    Handles Redis operations for real-time metrics and alerts.
    
    Key patterns:
    - field:{field_id}:latest          - Hash with latest metrics
    - field:{field_id}:rolling:{period} - Hash with rolling aggregates
    - alerts                           - Stream for alert events
    - farm:{farm_id}:schedule          - Sorted set for maintenance schedule
    - risk:{level}:fields              - Set of fields at each risk level
    - cache:{query_hash}               - Cached query results
    """
    
    def __init__(self, host: str = REDIS_HOST, port: int = REDIS_PORT):
        self.host = host
        self.port = port
        self.client = None
        
    def connect(self):
        """Establish connection to Redis."""
        print(f"Connecting to Redis at {self.host}:{self.port}...")
        # import redis
        # self.client = redis.Redis(host=self.host, port=self.port, decode_responses=True)
        # self.client.ping()
        print("  Connected successfully (simulated)")
        return True
    
    def update_latest_metrics(self, field_id: str, metrics: Dict):
        """
        Update latest metrics for a field.
        
        Redis command:
        HSET field:{field_id}:latest ndvi 0.72 soil_moisture 28.5 ...
        EXPIRE field:{field_id}:latest 900
        """
        key = f"field:{field_id}:latest"
        
        # Add timestamp
        metrics['updated_at'] = datetime.utcnow().isoformat()
        
        # Convert all values to strings for Redis
        flat_metrics = {k: str(v) for k, v in metrics.items()}
        
        print(f"  HSET {key} {' '.join([f'{k} {v}' for k, v in list(flat_metrics.items())[:3]])}...")
        print(f"  EXPIRE {key} {TTL_LATEST_METRICS}")
        
        # self.client.hset(key, mapping=flat_metrics)
        # self.client.expire(key, TTL_LATEST_METRICS)
        
        return key
    
    def compute_rolling_aggregates(self, field_id: str, sensor_data: List[Dict], 
                                    period_days: int = 7) -> Dict:
        """
        Compute rolling aggregates from sensor data.
        
        Redis command:
        HSET field:{field_id}:rolling:7d avg_ndvi 0.68 avg_soil_moisture 25.3 ...
        EXPIRE field:{field_id}:rolling:7d 3600
        """
        key = f"field:{field_id}:rolling:{period_days}d"
        
        # Filter data for the rolling window
        cutoff = datetime.utcnow() - timedelta(days=period_days)
        
        # Group by metric type
        metrics_by_type = defaultdict(list)
        for reading in sensor_data:
            if reading['field_id'] != field_id:
                continue
            ts = datetime.fromisoformat(reading['sensor_ts'].replace('Z', '+00:00'))
            if ts.replace(tzinfo=None) >= cutoff:
                metrics_by_type[reading['metric_type']].append(reading['metric_value'])
        
        # Compute aggregates
        aggregates = {'computed_at': datetime.utcnow().isoformat()}
        
        for metric_type, values in metrics_by_type.items():
            if values:
                aggregates[f'avg_{metric_type}'] = round(sum(values) / len(values), 3)
                aggregates[f'min_{metric_type}'] = round(min(values), 3)
                aggregates[f'max_{metric_type}'] = round(max(values), 3)
        
        # Compute trends (difference between first and last third)
        for metric_type, values in metrics_by_type.items():
            if len(values) >= 6:
                third = len(values) // 3
                early_avg = sum(values[:third]) / third
                late_avg = sum(values[-third:]) / third
                aggregates[f'{metric_type}_trend'] = round(late_avg - early_avg, 4)
        
        flat_aggs = {k: str(v) for k, v in aggregates.items()}
        
        print(f"  HSET {key} (with {len(flat_aggs)} metrics)")
        print(f"  EXPIRE {key} {TTL_ROLLING_AGGREGATES}")
        
        # self.client.hset(key, mapping=flat_aggs)
        # self.client.expire(key, TTL_ROLLING_AGGREGATES)
        
        return aggregates
    
    def check_and_create_alert(self, field_id: str, metrics: Dict, farm_id: str) -> Optional[Dict]:
        """
        Check metrics against thresholds and create alerts.
        
        Redis command:
        XADD alerts * field_id field_001 alert_type moisture_low value 9.2 ...
        """
        alerts = []
        
        # Check soil moisture
        moisture = metrics.get('soil_moisture', 100)
        if moisture < THRESHOLDS['soil_moisture_critical']:
            alerts.append({
                'field_id': field_id,
                'farm_id': farm_id,
                'alert_type': 'moisture_critical',
                'metric': 'soil_moisture',
                'value': moisture,
                'threshold': THRESHOLDS['soil_moisture_critical'],
                'severity': 'critical',
                'message': f"Critical: Soil moisture at {moisture}% (threshold: {THRESHOLDS['soil_moisture_critical']}%)"
            })
        elif moisture < THRESHOLDS['soil_moisture_low']:
            alerts.append({
                'field_id': field_id,
                'farm_id': farm_id,
                'alert_type': 'moisture_low',
                'metric': 'soil_moisture',
                'value': moisture,
                'threshold': THRESHOLDS['soil_moisture_low'],
                'severity': 'warning',
                'message': f"Warning: Soil moisture at {moisture}% (threshold: {THRESHOLDS['soil_moisture_low']}%)"
            })
        
        # Check NDVI
        ndvi = metrics.get('ndvi', 1.0)
        if ndvi < THRESHOLDS['ndvi_critical']:
            alerts.append({
                'field_id': field_id,
                'farm_id': farm_id,
                'alert_type': 'ndvi_critical',
                'metric': 'ndvi',
                'value': ndvi,
                'threshold': THRESHOLDS['ndvi_critical'],
                'severity': 'critical',
                'message': f"Critical: NDVI at {ndvi} (threshold: {THRESHOLDS['ndvi_critical']})"
            })
        elif ndvi < THRESHOLDS['ndvi_low']:
            alerts.append({
                'field_id': field_id,
                'farm_id': farm_id,
                'alert_type': 'ndvi_low',
                'metric': 'ndvi',
                'value': ndvi,
                'threshold': THRESHOLDS['ndvi_low'],
                'severity': 'warning',
                'message': f"Warning: NDVI at {ndvi} (threshold: {THRESHOLDS['ndvi_low']})"
            })
        
        # Check temperature
        temp = metrics.get('temperature', 0)
        if temp > THRESHOLDS['temperature_high']:
            alerts.append({
                'field_id': field_id,
                'farm_id': farm_id,
                'alert_type': 'temperature_high',
                'metric': 'temperature',
                'value': temp,
                'threshold': THRESHOLDS['temperature_high'],
                'severity': 'warning',
                'message': f"Warning: Temperature at {temp}°C (threshold: {THRESHOLDS['temperature_high']}°C)"
            })
        
        # Check grass height
        height = metrics.get('grass_height', 100)
        if height < THRESHOLDS['grass_height_low']:
            alerts.append({
                'field_id': field_id,
                'farm_id': farm_id,
                'alert_type': 'grass_height_low',
                'metric': 'grass_height',
                'value': height,
                'threshold': THRESHOLDS['grass_height_low'],
                'severity': 'warning',
                'message': f"Warning: Grass height at {height}cm (threshold: {THRESHOLDS['grass_height_low']}cm)"
            })
        
        # Push alerts to stream
        for alert in alerts:
            alert['timestamp'] = datetime.utcnow().isoformat()
            flat_alert = {k: str(v) for k, v in alert.items()}
            
            print(f"  XADD alerts * {' '.join([f'{k} {v}' for k, v in list(flat_alert.items())[:4]])}...")
            # self.client.xadd('alerts', flat_alert)
            
            # Also publish to farm-specific channel
            channel = f"farm:{farm_id}:alerts"
            print(f"  PUBLISH {channel} {json.dumps(alert)[:50]}...")
            # self.client.publish(channel, json.dumps(alert))
        
        return alerts if alerts else None
    
    def update_risk_classification(self, field_id: str, risk_level: str):
        """
        Update field risk classification in Redis sets.
        
        Redis commands:
        SREM risk:low:fields field_001
        SREM risk:medium:fields field_001
        SREM risk:high:fields field_001
        SADD risk:{level}:fields field_001
        """
        risk_levels = ['low', 'medium', 'high', 'critical']
        
        # Remove from all risk sets
        for level in risk_levels:
            key = f"risk:{level}:fields"
            print(f"  SREM {key} {field_id}")
            # self.client.srem(key, field_id)
        
        # Add to correct risk set
        key = f"risk:{risk_level}:fields"
        print(f"  SADD {key} {field_id}")
        print(f"  EXPIRE {key} {TTL_RISK_SETS}")
        # self.client.sadd(key, field_id)
        # self.client.expire(key, TTL_RISK_SETS)
    
    def schedule_maintenance(self, farm_id: str, task: Dict, scheduled_timestamp: float):
        """
        Add task to maintenance schedule (sorted set).
        
        Redis command:
        ZADD farm:{farm_id}:schedule {timestamp} {task_json}
        """
        key = f"farm:{farm_id}:schedule"
        task_json = json.dumps(task)
        
        print(f"  ZADD {key} {scheduled_timestamp} {task_json[:50]}...")
        # self.client.zadd(key, {task_json: scheduled_timestamp})
    
    def get_upcoming_tasks(self, farm_id: str, hours: int = 48) -> List[Dict]:
        """
        Get upcoming scheduled tasks.
        
        Redis command:
        ZRANGEBYSCORE farm:{farm_id}:schedule {now} {now + hours}
        """
        key = f"farm:{farm_id}:schedule"
        now = datetime.utcnow().timestamp()
        end = now + (hours * 3600)
        
        print(f"  ZRANGEBYSCORE {key} {now} {end}")
        # tasks = self.client.zrangebyscore(key, now, end)
        # return [json.loads(t) for t in tasks]
        return []
    
    def cache_query_result(self, query_hash: str, result: str):
        """
        Cache a query result.
        
        Redis commands:
        SET cache:{query_hash} {result}
        EXPIRE cache:{query_hash} 300
        """
        key = f"cache:{query_hash}"
        print(f"  SET {key} {result[:50]}...")
        print(f"  EXPIRE {key} {TTL_CACHE}")
        # self.client.set(key, result, ex=TTL_CACHE)
    
    def close(self):
        """Close Redis connection."""
        print("\nClosing Redis connection...")
        # Connection will be closed by garbage collection
        print("  Connection closed")


# =============================================================================
# Sample Redis Commands
# =============================================================================

SAMPLE_COMMANDS = """
# =============================================================================
# REDIS COMMANDS REFERENCE
# =============================================================================

# --- HASHES: Latest Metrics per Field ---

# Set latest metrics for a field
HSET field:field_001:latest \\
    ndvi 0.72 \\
    soil_moisture 28.5 \\
    grass_height_cm 12.3 \\
    temperature_c 18.5 \\
    humidity_pct 65 \\
    updated_at "2024-10-15T14:30:00Z" \\
    risk_score 0.25

# Set TTL (15 minutes)
EXPIRE field:field_001:latest 900

# Get all latest metrics
HGETALL field:field_001:latest

# Get specific metric
HGET field:field_001:latest ndvi

# --- HASHES: Rolling Aggregates ---

HSET field:field_001:rolling:7d \\
    avg_ndvi 0.68 \\
    avg_soil_moisture 25.3 \\
    min_soil_moisture 18.2 \\
    max_temperature_c 28.5 \\
    ndvi_trend -0.04 \\
    computed_at "2024-10-15T15:00:00Z"

EXPIRE field:field_001:rolling:7d 3600

# --- STREAMS: Alert Events ---

# Add alert to stream
XADD alerts * \\
    field_id field_001 \\
    farm_id farm_001 \\
    alert_type moisture_low \\
    value 9.2 \\
    threshold 15.0 \\
    severity warning \\
    timestamp "2024-10-15T14:35:00Z" \\
    message "Soil moisture below threshold"

# Read latest alerts
XREVRANGE alerts + - COUNT 10

# Create consumer group for alert processing
XGROUP CREATE alerts alert_processors $ MKSTREAM

# Read alerts as consumer
XREADGROUP GROUP alert_processors worker1 COUNT 10 STREAMS alerts >

# Acknowledge processed alert
XACK alerts alert_processors <message-id>

# --- SORTED SETS: Maintenance Schedule ---

# Add scheduled task (score = unix timestamp)
ZADD farm:farm_001:schedule \\
    1729036800 '{"task":"fertilize","field_id":"field_001","priority":"high"}' \\
    1729123200 '{"task":"irrigate","field_id":"field_002","priority":"medium"}'

# Get tasks in next 48 hours
ZRANGEBYSCORE farm:farm_001:schedule <now> <now+172800>

# Remove completed task
ZREM farm:farm_001:schedule '{"task":"fertilize",...}'

# --- SETS: Fields by Risk Level ---

# Add fields to risk sets
SADD risk:high:fields field_001 field_005 field_012
SADD risk:medium:fields field_002 field_003 field_008
SADD risk:low:fields field_004 field_006 field_007

# Get all high-risk fields
SMEMBERS risk:high:fields

# Count fields at each risk level
SCARD risk:high:fields
SCARD risk:medium:fields
SCARD risk:low:fields

# Move field between risk levels
SMOVE risk:medium:fields risk:high:fields field_003

# --- PUB/SUB: Real-time Notifications ---

# Subscribe to farm alerts (in a separate client)
SUBSCRIBE farm:farm_001:alerts

# Publish alert
PUBLISH farm:farm_001:alerts '{"field_id":"field_001","type":"drought_warning"}'

# Pattern subscribe to all farm alerts
PSUBSCRIBE farm:*:alerts

# --- CACHING ---

# Cache query result
SET cache:geo_query_5km_station1 '[{"field_id":"field_001","distance_m":1200}]'
EXPIRE cache:geo_query_5km_station1 300

# Get cached result
GET cache:geo_query_5km_station1

# Check TTL
TTL cache:geo_query_5km_station1
"""


# =============================================================================
# Main Function
# =============================================================================

def main():
    """Main aggregation workflow."""
    print("="*60)
    print("REDIS AGGREGATION - Pasture Management System")
    print("="*60)
    
    # Load data
    sensor_file = os.path.join(DATA_DIR, "sensor_data.json")
    fields_file = os.path.join(DATA_DIR, "fields.json")
    
    if not os.path.exists(sensor_file) or not os.path.exists(fields_file):
        print("\nData files not found. Run data_generator.py first.")
        return
    
    print(f"\nLoading sensor data from {sensor_file}...")
    with open(sensor_file, 'r') as f:
        sensor_data = json.load(f)
    print(f"  Loaded {len(sensor_data):,} sensor readings")
    
    print(f"Loading field data from {fields_file}...")
    with open(fields_file, 'r') as f:
        fields = json.load(f)
    print(f"  Loaded {len(fields)} fields")
    
    # Initialize Redis connection
    aggregator = RedisAggregator()
    
    try:
        aggregator.connect()
        
        print("\n" + "="*60)
        print("UPDATING LATEST METRICS")
        print("="*60)
        
        # Process each field
        alerts_generated = 0
        for field in fields[:5]:  # Demo with first 5 fields
            field_id = field['field_id']
            farm_id = field['farm_id']
            
            print(f"\nProcessing {field_id}...")
            
            # Get latest metrics from field data
            metrics = field.get('latest_metrics', {})
            
            # Update latest metrics in Redis
            aggregator.update_latest_metrics(field_id, metrics)
            
            # Compute rolling aggregates
            rolling = aggregator.compute_rolling_aggregates(field_id, sensor_data, period_days=7)
            
            # Check for alerts
            alerts = aggregator.check_and_create_alert(field_id, metrics, farm_id)
            if alerts:
                alerts_generated += len(alerts)
                
                # Update risk classification based on alerts
                if any(a['severity'] == 'critical' for a in alerts):
                    aggregator.update_risk_classification(field_id, 'critical')
                elif any(a['severity'] == 'warning' for a in alerts):
                    aggregator.update_risk_classification(field_id, 'high')
                else:
                    aggregator.update_risk_classification(field_id, 'medium')
            else:
                aggregator.update_risk_classification(field_id, 'low')
        
        print(f"\nTotal alerts generated: {alerts_generated}")
        
        # Print sample commands
        print("\n" + "="*60)
        print("REDIS COMMANDS REFERENCE")
        print("="*60)
        print(SAMPLE_COMMANDS)
        
    finally:
        aggregator.close()
    
    print("\n" + "="*60)
    print("AGGREGATION COMPLETE")
    print("="*60)


if __name__ == "__main__":
    main()

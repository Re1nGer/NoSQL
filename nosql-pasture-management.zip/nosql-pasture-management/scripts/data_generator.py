#!/usr/bin/env python3
"""
Synthetic Data Generator for Pasture Management System

Generates realistic sensor data, farm/field metadata, and events
for testing the NoSQL pasture management pipeline.

Generation Method:
- Uses Faker for realistic names and addresses
- Uses mathematical models for sensor data with seasonal patterns
- Simulates realistic correlations between metrics (e.g., NDVI drops when soil is dry)
"""

import json
import random
import math
from datetime import datetime, timedelta
from typing import List, Dict, Any
from dataclasses import dataclass, asdict
import os

# Try to import optional dependencies
try:
    from faker import Faker
    fake = Faker()
except ImportError:
    fake = None
    print("Warning: Faker not installed. Using basic name generation.")

# Seed for reproducibility
random.seed(42)

# =============================================================================
# Configuration
# =============================================================================

NUM_FARMS = 5
FIELDS_PER_FARM = (3, 8)  # Range
SENSORS_PER_FIELD = (2, 5)
DAYS_OF_DATA = 90
READINGS_PER_DAY = 24  # Hourly

# Geographic bounds (US Midwest - prime pasture land)
LAT_BOUNDS = (41.0, 45.0)
LON_BOUNDS = (-93.0, -87.0)

# Soil types and their characteristics
SOIL_TYPES = {
    "loam": {"moisture_retention": 0.7, "ph_range": (6.0, 7.0), "quality": "excellent"},
    "sandy_loam": {"moisture_retention": 0.5, "ph_range": (5.5, 6.5), "quality": "good"},
    "clay": {"moisture_retention": 0.9, "ph_range": (5.5, 7.5), "quality": "moderate"},
    "silt": {"moisture_retention": 0.75, "ph_range": (6.0, 7.0), "quality": "good"},
    "clay_loam": {"moisture_retention": 0.8, "ph_range": (5.8, 7.2), "quality": "good"},
}

# Grass species for pastures
GRASS_SPECIES = [
    {"id": "sp_001", "name": "Perennial Ryegrass", "scientific": "Lolium perenne", "drought_tol": "medium"},
    {"id": "sp_002", "name": "White Clover", "scientific": "Trifolium repens", "drought_tol": "low"},
    {"id": "sp_003", "name": "Timothy", "scientific": "Phleum pratense", "drought_tol": "medium"},
    {"id": "sp_004", "name": "Kentucky Bluegrass", "scientific": "Poa pratensis", "drought_tol": "low"},
    {"id": "sp_005", "name": "Tall Fescue", "scientific": "Festuca arundinacea", "drought_tol": "high"},
    {"id": "sp_006", "name": "Orchardgrass", "scientific": "Dactylis glomerata", "drought_tol": "medium"},
]

# Treatment types
TREATMENT_TYPES = ["fertilizer", "lime", "irrigation", "herbicide", "overseeding", "mowing"]

# =============================================================================
# Helper Functions
# =============================================================================

def generate_name(prefix: str, index: int) -> str:
    """Generate a realistic name using Faker if available."""
    if fake:
        adjectives = ["Green", "Golden", "Sunny", "Rolling", "Peaceful", "Oak", "Willow", "Cedar"]
        nouns = ["Valley", "Hills", "Meadow", "Fields", "Pastures", "Acres", "Creek", "Ridge"]
        return f"{random.choice(adjectives)} {random.choice(nouns)} {prefix}"
    return f"{prefix}_{index:03d}"


def generate_polygon(center_lat: float, center_lon: float, area_ha: float) -> Dict:
    """Generate a GeoJSON polygon around a center point."""
    # Approximate size based on area (1 hectare ≈ 0.01 sq km)
    side_km = math.sqrt(area_ha / 100)  # Approximate side length in km
    lat_offset = side_km / 111  # 1 degree lat ≈ 111 km
    lon_offset = side_km / (111 * math.cos(math.radians(center_lat)))
    
    # Create irregular polygon (not a perfect square)
    points = [
        [center_lon - lon_offset * random.uniform(0.8, 1.2), 
         center_lat + lat_offset * random.uniform(0.8, 1.2)],
        [center_lon + lon_offset * random.uniform(0.8, 1.2), 
         center_lat + lat_offset * random.uniform(0.8, 1.2)],
        [center_lon + lon_offset * random.uniform(0.8, 1.2), 
         center_lat - lat_offset * random.uniform(0.8, 1.2)],
        [center_lon - lon_offset * random.uniform(0.8, 1.2), 
         center_lat - lat_offset * random.uniform(0.8, 1.2)],
    ]
    points.append(points[0])  # Close the polygon
    
    return {"type": "Polygon", "coordinates": [points]}


def seasonal_factor(day_of_year: int) -> float:
    """Calculate seasonal growth factor (0-1) based on day of year."""
    # Peak growth in late spring/early summer (day 150-180)
    # Minimum in winter (day 0 and 365)
    return 0.5 + 0.5 * math.sin((day_of_year - 80) * 2 * math.pi / 365)


def weather_variation(hour: int, base_temp: float) -> Dict[str, float]:
    """Generate hourly weather variation."""
    # Temperature peaks around 2 PM
    hour_factor = math.sin((hour - 6) * math.pi / 12) if 6 <= hour <= 18 else -0.3
    temp = base_temp + hour_factor * 8 + random.gauss(0, 2)
    
    # Humidity inversely related to temperature
    humidity = 70 - hour_factor * 30 + random.gauss(0, 10)
    humidity = max(20, min(100, humidity))
    
    return {
        "temperature": round(temp, 1),
        "humidity": round(humidity, 1),
        "wind_speed": round(abs(random.gauss(10, 5)), 1),
    }


# =============================================================================
# Data Generators
# =============================================================================

def generate_farms(num_farms: int) -> List[Dict]:
    """Generate farm documents."""
    farms = []
    for i in range(num_farms):
        farm_id = f"farm_{i+1:03d}"
        farmer_id = f"farmer_{i+1:03d}"
        
        lat = random.uniform(*LAT_BOUNDS)
        lon = random.uniform(*LON_BOUNDS)
        
        farm = {
            "farm_id": farm_id,
            "name": generate_name("Farm", i+1),
            "owner": {
                "farmer_id": farmer_id,
                "name": fake.name() if fake else f"Farmer {i+1}",
                "contact": {
                    "email": fake.email() if fake else f"farmer{i+1}@example.com",
                    "phone": fake.phone_number() if fake else f"+1-555-{i+1:04d}"
                }
            },
            "location": {
                "address": fake.address() if fake else f"{i+1} Rural Road",
                "region": random.choice(["Midwest", "Northeast", "Northwest", "Central"]),
                "country": "USA",
                "center": {
                    "type": "Point",
                    "coordinates": [round(lon, 6), round(lat, 6)]
                }
            },
            "total_area_ha": round(random.uniform(100, 500), 1),
            "established_date": (datetime.now() - timedelta(days=random.randint(1000, 10000))).isoformat(),
            "certifications": random.sample(["Organic", "Grass-Fed", "Sustainable", "Non-GMO"], 
                                           k=random.randint(0, 3)),
            "metadata": {
                "last_inspection": (datetime.now() - timedelta(days=random.randint(30, 365))).isoformat(),
                "risk_score": round(random.uniform(0.1, 0.5), 2)
            }
        }
        farms.append(farm)
    
    return farms


def generate_fields(farms: List[Dict]) -> List[Dict]:
    """Generate field documents for each farm."""
    fields = []
    field_counter = 1
    
    for farm in farms:
        farm_center = farm["location"]["center"]["coordinates"]
        num_fields = random.randint(*FIELDS_PER_FARM)
        
        for j in range(num_fields):
            field_id = f"field_{field_counter:03d}"
            
            # Offset from farm center
            lat = farm_center[1] + random.uniform(-0.02, 0.02)
            lon = farm_center[0] + random.uniform(-0.02, 0.02)
            area = round(random.uniform(10, 80), 1)
            
            soil_type = random.choice(list(SOIL_TYPES.keys()))
            
            # Select 2-4 species for the field
            num_species = random.randint(2, 4)
            selected_species = random.sample(GRASS_SPECIES, num_species)
            coverages = [random.randint(10, 50) for _ in range(num_species)]
            total = sum(coverages)
            coverages = [int(c * 100 / total) for c in coverages]
            
            species_list = [
                {
                    "species_id": sp["id"],
                    "name": sp["name"],
                    "coverage_pct": cov
                }
                for sp, cov in zip(selected_species, coverages)
            ]
            
            # Generate sensor IDs
            num_sensors = random.randint(*SENSORS_PER_FIELD)
            sensor_types = ["soil_moisture", "weather", "ndvi", "grass_height"]
            sensors = [
                f"sensor_{st}_{field_counter:03d}_{k+1:02d}"
                for k, st in enumerate(random.sample(sensor_types, min(num_sensors, len(sensor_types))))
            ]
            
            field = {
                "field_id": field_id,
                "farm_id": farm["farm_id"],
                "name": random.choice(["North", "South", "East", "West", "Upper", "Lower"]) + " " +
                        random.choice(["Pasture", "Meadow", "Field", "Paddock"]),
                "boundary": generate_polygon(lat, lon, area),
                "area_ha": area,
                "soil_type": soil_type,
                "terrain": {
                    "elevation_m": round(random.uniform(200, 500), 0),
                    "slope_pct": round(random.uniform(0, 15), 1),
                    "aspect": random.choice(["north", "south", "east", "west", "flat"])
                },
                "establishment_date": (datetime.now() - timedelta(days=random.randint(500, 5000))).isoformat(),
                "current_species": species_list,
                "sensors": sensors,
                "latest_metrics": {
                    "ndvi": round(random.uniform(0.4, 0.8), 2),
                    "soil_moisture": round(random.uniform(15, 40), 1),
                    "grass_height_cm": round(random.uniform(5, 25), 1),
                    "temperature_c": round(random.uniform(15, 25), 1),
                    "updated_at": datetime.now().isoformat()
                },
                "notes": random.sample([
                    "Excellent drainage",
                    "Reseeded in 2022",
                    "Prone to waterlogging",
                    "High productivity",
                    "Needs lime application",
                    "Good shelter from wind"
                ], k=random.randint(0, 2))
            }
            fields.append(field)
            field_counter += 1
    
    return fields


def generate_sensor_data(fields: List[Dict], days: int = 90) -> List[Dict]:
    """
    Generate time-series sensor data for Cassandra.
    
    Creates realistic correlated data:
    - NDVI correlates with soil moisture and temperature
    - Grass height correlates with NDVI and seasonal factors
    - Weather data has diurnal patterns
    """
    sensor_data = []
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    for field in fields:
        field_id = field["field_id"]
        soil_props = SOIL_TYPES.get(field["soil_type"], SOIL_TYPES["loam"])
        base_moisture = 25 * soil_props["moisture_retention"]
        
        # Create a "drought event" for some fields (for interesting analysis)
        has_drought = random.random() < 0.2
        drought_start_day = random.randint(30, 60) if has_drought else -1
        drought_duration = random.randint(10, 20) if has_drought else 0
        
        current_date = start_date
        day_counter = 0
        
        while current_date < end_date:
            day_of_year = current_date.timetuple().tm_yday
            season = seasonal_factor(day_of_year)
            
            # Check if in drought period
            in_drought = drought_start_day <= day_counter < drought_start_day + drought_duration
            drought_factor = 0.4 if in_drought else 1.0
            
            # Base values for the day
            base_temp = 10 + season * 20  # 10-30°C range
            daily_precip = 0 if in_drought else random.random() * 5 * (1 if random.random() < 0.3 else 0)
            
            for hour in range(0, 24, 1):  # Hourly readings
                ts = current_date.replace(hour=hour)
                weather = weather_variation(hour, base_temp)
                
                # Soil moisture (affected by precipitation and evaporation)
                soil_moisture = base_moisture * drought_factor + daily_precip * 2 - (weather["temperature"] - 15) * 0.5
                soil_moisture = max(5, min(50, soil_moisture + random.gauss(0, 3)))
                
                # NDVI (vegetation health) - correlated with moisture and season
                ndvi_base = 0.3 + 0.4 * season * drought_factor
                ndvi = ndvi_base + (soil_moisture - 20) * 0.01
                ndvi = max(0.1, min(0.9, ndvi + random.gauss(0, 0.05)))
                
                # Grass height (cumulative growth minus grazing)
                grass_height = 5 + 15 * season * ndvi + random.gauss(0, 2)
                grass_height = max(2, min(40, grass_height))
                
                # pH (relatively stable)
                ph = random.uniform(*soil_props["ph_range"])
                
                # Create sensor readings
                readings = [
                    {"sensor_id": f"sensor_soil_moisture_{field_id}", "metric_type": "soil_moisture", 
                     "metric_value": round(soil_moisture, 1), "unit": "%"},
                    {"sensor_id": f"sensor_temp_{field_id}", "metric_type": "temperature",
                     "metric_value": round(weather["temperature"], 1), "unit": "celsius"},
                    {"sensor_id": f"sensor_humidity_{field_id}", "metric_type": "humidity",
                     "metric_value": round(weather["humidity"], 1), "unit": "%"},
                    {"sensor_id": f"sensor_ndvi_{field_id}", "metric_type": "ndvi",
                     "metric_value": round(ndvi, 3), "unit": "index"},
                    {"sensor_id": f"sensor_height_{field_id}", "metric_type": "grass_height",
                     "metric_value": round(grass_height, 1), "unit": "cm"},
                    {"sensor_id": f"sensor_ph_{field_id}", "metric_type": "soil_ph",
                     "metric_value": round(ph, 1), "unit": "pH"},
                    {"sensor_id": f"sensor_wind_{field_id}", "metric_type": "wind_speed",
                     "metric_value": round(weather["wind_speed"], 1), "unit": "km/h"},
                ]
                
                for reading in readings:
                    sensor_data.append({
                        "field_id": field_id,
                        "farm_id": field["farm_id"],
                        "sensor_ts": ts.isoformat(),
                        "quality_flag": 1 if random.random() > 0.02 else 0,  # 2% bad readings
                        **reading
                    })
            
            current_date += timedelta(days=1)
            day_counter += 1
    
    return sensor_data


def generate_treatment_events(fields: List[Dict], farms: List[Dict]) -> List[Dict]:
    """Generate treatment event history."""
    events = []
    event_counter = 1
    
    for field in fields:
        # 3-8 treatments per field over the past year
        num_treatments = random.randint(3, 8)
        
        for _ in range(num_treatments):
            treatment_type = random.choice(TREATMENT_TYPES)
            days_ago = random.randint(1, 365)
            
            event = {
                "event_id": f"event_{event_counter:04d}",
                "field_id": field["field_id"],
                "farm_id": field["farm_id"],
                "treatment_type": treatment_type,
                "treatment_details": get_treatment_details(treatment_type),
                "applied_date": (datetime.now() - timedelta(days=days_ago)).isoformat(),
                "applied_by": field["farm_id"].replace("farm", "farmer"),
                "weather_conditions": {
                    "temperature_c": round(random.uniform(10, 25), 1),
                    "wind_speed_kmh": round(random.uniform(0, 20), 1),
                    "precipitation_mm": round(random.uniform(0, 5), 1)
                },
                "cost_usd": round(random.uniform(50, 500), 2),
                "notes": random.choice([
                    "Applied before predicted rain",
                    "Routine application",
                    "Response to soil test results",
                    "Preventive treatment",
                    "Scheduled maintenance",
                    ""
                ]),
                "created_at": (datetime.now() - timedelta(days=days_ago)).isoformat()
            }
            events.append(event)
            event_counter += 1
    
    return events


def get_treatment_details(treatment_type: str) -> Dict:
    """Get realistic treatment details based on type."""
    details = {
        "fertilizer": {
            "product": random.choice(["Urea 46-0-0", "DAP 18-46-0", "NPK 10-10-10", "Ammonium Nitrate"]),
            "rate": random.randint(30, 100),
            "unit": "kg/ha",
            "method": random.choice(["broadcast", "injection", "foliar spray"])
        },
        "lime": {
            "product": random.choice(["Agricultural Lime", "Dolomite Lime", "Calcitic Lime"]),
            "rate": random.randint(1000, 3000),
            "unit": "kg/ha",
            "method": "broadcast"
        },
        "irrigation": {
            "product": "Water",
            "rate": random.randint(15, 50),
            "unit": "mm",
            "method": random.choice(["sprinkler", "drip", "flood"])
        },
        "herbicide": {
            "product": random.choice(["Glyphosate", "2,4-D", "MCPA", "Dicamba"]),
            "rate": round(random.uniform(1, 5), 1),
            "unit": "L/ha",
            "method": "spray"
        },
        "overseeding": {
            "product": random.choice(["Ryegrass mix", "Clover blend", "Drought-tolerant mix"]),
            "rate": random.randint(10, 30),
            "unit": "kg/ha",
            "method": "broadcast"
        },
        "mowing": {
            "product": "N/A",
            "rate": random.randint(5, 15),
            "unit": "cm_height",
            "method": "rotary"
        }
    }
    return details.get(treatment_type, {"product": "Unknown", "rate": 0, "unit": "N/A", "method": "N/A"})


def generate_grazing_events(fields: List[Dict]) -> List[Dict]:
    """Generate grazing history."""
    events = []
    event_counter = 1
    
    for field in fields:
        # 2-6 grazing events per field
        num_events = random.randint(2, 6)
        
        for _ in range(num_events):
            start_days_ago = random.randint(7, 180)
            duration = random.randint(3, 14)
            
            event = {
                "event_id": f"graze_{event_counter:04d}",
                "field_id": field["field_id"],
                "farm_id": field["farm_id"],
                "livestock_type": random.choice(["cattle", "sheep", "goats", "horses"]),
                "head_count": random.randint(10, 100),
                "start_date": (datetime.now() - timedelta(days=start_days_ago)).isoformat(),
                "end_date": (datetime.now() - timedelta(days=start_days_ago - duration)).isoformat(),
                "stocking_rate": round(random.uniform(1, 4), 1),
                "utilization_pct": random.randint(40, 80),
                "notes": random.choice([
                    "Rotational grazing",
                    "Strip grazing",
                    "Continuous grazing",
                    "Leader-follower system"
                ])
            }
            events.append(event)
            event_counter += 1
    
    return events


def generate_advisory_rules() -> List[Dict]:
    """Generate advisory rules for Neo4j."""
    rules = [
        {
            "rule_id": "rule_001",
            "name": "Low Soil Moisture Alert",
            "description": "Trigger irrigation when soil moisture drops below threshold",
            "trigger_condition": "soil_moisture < 15 AND forecast_rain_mm < 5",
            "priority": 1,
            "action": "Schedule irrigation within 48 hours",
            "expected_outcome": "Prevent forage stress and maintain NDVI above 0.5",
            "applies_to_species": ["sp_001", "sp_002", "sp_003"],
            "applies_to_soil_types": ["sandy_loam", "loam"]
        },
        {
            "rule_id": "rule_002",
            "name": "Overgrazing Prevention",
            "description": "Reduce stocking rate when grass height and NDVI decline",
            "trigger_condition": "grass_height < 6 AND ndvi_trend_14d < -0.1",
            "priority": 1,
            "action": "Reduce stocking rate by 20% and enforce 21-day rest period",
            "expected_outcome": "Allow pasture recovery within 3-4 weeks",
            "applies_to_species": ["sp_001", "sp_003", "sp_006"],
            "applies_to_soil_types": ["all"]
        },
        {
            "rule_id": "rule_003",
            "name": "Acidic Soil Amendment",
            "description": "Apply lime when soil pH is too low",
            "trigger_condition": "soil_ph < 5.8",
            "priority": 2,
            "action": "Apply 2000 kg/ha agricultural lime in fall",
            "expected_outcome": "Raise pH to optimal range (6.0-6.5) within 6 months",
            "applies_to_species": ["sp_001", "sp_002", "sp_004"],
            "applies_to_soil_types": ["all"]
        },
        {
            "rule_id": "rule_004",
            "name": "Nitrogen Deficiency Response",
            "description": "Apply nitrogen when growth is limited and soil N is low",
            "trigger_condition": "ndvi < 0.5 AND soil_n_ppm < 20 AND season = 'spring'",
            "priority": 2,
            "action": "Apply 50 kg/ha nitrogen in split applications",
            "expected_outcome": "Increase biomass production by 20-30% within 4 weeks",
            "applies_to_species": ["sp_001", "sp_003", "sp_005", "sp_006"],
            "applies_to_soil_types": ["all"]
        },
        {
            "rule_id": "rule_005",
            "name": "Slope Erosion Risk",
            "description": "Prevent overuse on steep slopes to reduce erosion",
            "trigger_condition": "slope_pct > 10 AND utilization_pct > 60",
            "priority": 1,
            "action": "Limit grazing to 50% utilization, consider reseeding with deep-rooted species",
            "expected_outcome": "Maintain ground cover and prevent soil loss",
            "applies_to_species": ["sp_005", "sp_006"],
            "applies_to_soil_types": ["all"]
        },
        {
            "rule_id": "rule_006",
            "name": "Heat Stress Management",
            "description": "Adjust management during extreme heat",
            "trigger_condition": "temperature > 30 AND humidity > 70",
            "priority": 1,
            "action": "Provide shade, reduce stocking density, ensure water access",
            "expected_outcome": "Prevent heat stress in livestock and pasture damage",
            "applies_to_species": ["all"],
            "applies_to_soil_types": ["all"]
        },
        {
            "rule_id": "rule_007",
            "name": "Drought Recovery Seeding",
            "description": "Reseed after prolonged drought damage",
            "trigger_condition": "ndvi < 0.3 for 30+ days AND drought_event = true",
            "priority": 3,
            "action": "Overseed with drought-tolerant species (Tall Fescue mix) at 15 kg/ha",
            "expected_outcome": "Restore ground cover within growing season",
            "applies_to_species": ["sp_005"],
            "applies_to_soil_types": ["all"]
        },
        {
            "rule_id": "rule_008",
            "name": "Optimal Grazing Window",
            "description": "Graze when pasture is at optimal height",
            "trigger_condition": "grass_height >= 15 AND grass_height <= 25 AND ndvi > 0.6",
            "priority": 3,
            "action": "Begin rotational grazing, target 50-60% utilization",
            "expected_outcome": "Maximize forage quality and regrowth potential",
            "applies_to_species": ["sp_001", "sp_003", "sp_004"],
            "applies_to_soil_types": ["all"]
        }
    ]
    return rules


def generate_weather_stations(farms: List[Dict]) -> List[Dict]:
    """Generate weather station data for proximity queries."""
    stations = []
    
    for i, farm in enumerate(farms):
        # Create 1-2 stations near each farm
        for j in range(random.randint(1, 2)):
            farm_coords = farm["location"]["center"]["coordinates"]
            station = {
                "station_id": f"ws_{i+1:03d}_{j+1}",
                "name": f"County Weather Station {i+1}-{j+1}",
                "latitude": farm_coords[1] + random.uniform(-0.1, 0.1),
                "longitude": farm_coords[0] + random.uniform(-0.1, 0.1),
                "elevation_m": random.randint(200, 500),
                "installed_date": (datetime.now() - timedelta(days=random.randint(365, 3650))).isoformat()
            }
            stations.append(station)
    
    return stations


# =============================================================================
# Main Generation Function
# =============================================================================

def generate_all_data(output_dir: str = "data"):
    """Generate all synthetic data and save to files."""
    os.makedirs(output_dir, exist_ok=True)
    
    print("Generating farms...")
    farms = generate_farms(NUM_FARMS)
    
    print("Generating fields...")
    fields = generate_fields(farms)
    
    print("Generating sensor data (this may take a moment)...")
    sensor_data = generate_sensor_data(fields, DAYS_OF_DATA)
    
    print("Generating treatment events...")
    treatment_events = generate_treatment_events(fields, farms)
    
    print("Generating grazing events...")
    grazing_events = generate_grazing_events(fields)
    
    print("Generating advisory rules...")
    advisory_rules = generate_advisory_rules()
    
    print("Generating weather stations...")
    weather_stations = generate_weather_stations(farms)
    
    # Generate farmer profiles from farm data
    farmer_profiles = []
    for farm in farms:
        farmer_profiles.append({
            "farmer_id": farm["owner"]["farmer_id"],
            "name": farm["owner"]["name"],
            "email": farm["owner"]["contact"]["email"],
            "phone": farm["owner"]["contact"]["phone"],
            "farms": [farm["farm_id"]],
            "preferences": {
                "alert_threshold_soil_moisture": random.randint(10, 20),
                "alert_threshold_ndvi": round(random.uniform(0.3, 0.5), 2),
                "notification_methods": random.sample(["email", "sms", "app"], k=random.randint(1, 3))
            },
            "subscription_tier": random.choice(["basic", "standard", "premium"]),
            "created_at": farm["established_date"]
        })
    
    # Save all data
    data_files = {
        "farms.json": farms,
        "fields.json": fields,
        "sensor_data.json": sensor_data,
        "treatment_events.json": treatment_events,
        "grazing_events.json": grazing_events,
        "advisory_rules.json": advisory_rules,
        "weather_stations.json": weather_stations,
        "farmer_profiles.json": farmer_profiles,
    }
    
    for filename, data in data_files.items():
        filepath = os.path.join(output_dir, filename)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        print(f"  Saved {filepath} ({len(data)} records)")
    
    # Summary
    print("\n" + "="*60)
    print("DATA GENERATION SUMMARY")
    print("="*60)
    print(f"Farms:            {len(farms)}")
    print(f"Fields:           {len(fields)}")
    print(f"Sensor readings:  {len(sensor_data):,}")
    print(f"Treatment events: {len(treatment_events)}")
    print(f"Grazing events:   {len(grazing_events)}")
    print(f"Advisory rules:   {len(advisory_rules)}")
    print(f"Weather stations: {len(weather_stations)}")
    print(f"Farmer profiles:  {len(farmer_profiles)}")
    print("="*60)
    
    return data_files


if __name__ == "__main__":
    generate_all_data()

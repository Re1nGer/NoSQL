#!/usr/bin/env python3
"""
MongoDB Ingestion Script for Pasture Management System

Ingests farm metadata, field information, and events into MongoDB.
Demonstrates:
- Document model design
- Geospatial indexing (2dsphere)
- Aggregation pipelines
- Upsert operations
"""

import json
import os
from datetime import datetime
from typing import List, Dict, Any

# =============================================================================
# Configuration
# =============================================================================

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
DATABASE = os.getenv("MONGODB_DATABASE", "pasture_mgmt")
DATA_DIR = os.getenv("DATA_DIR", "data")

# =============================================================================
# Collection Schemas
# =============================================================================

COLLECTION_SCHEMAS = {
    "farms": {
        "description": "Farm-level information and ownership",
        "indexes": [
            {"keys": [("farm_id", 1)], "unique": True},
            {"keys": [("location.center", "2dsphere")]},
            {"keys": [("owner.farmer_id", 1)]}
        ]
    },
    "fields": {
        "description": "Field metadata with geospatial boundaries",
        "indexes": [
            {"keys": [("field_id", 1)], "unique": True},
            {"keys": [("farm_id", 1), ("field_id", 1)]},
            {"keys": [("boundary", "2dsphere")]},
            {"keys": [("latest_metrics.ndvi", 1)]},
            {"keys": [("latest_metrics.soil_moisture", 1)]},
            {"keys": [("soil_type", 1)]},
            {"keys": [("notes", "text")]}
        ]
    },
    "treatment_events": {
        "description": "Historical treatment records",
        "indexes": [
            {"keys": [("event_id", 1)], "unique": True},
            {"keys": [("field_id", 1), ("applied_date", -1)]},
            {"keys": [("treatment_type", 1)]},
            {"keys": [("farm_id", 1)]}
        ]
    },
    "grazing_events": {
        "description": "Livestock grazing history",
        "indexes": [
            {"keys": [("event_id", 1)], "unique": True},
            {"keys": [("field_id", 1), ("start_date", -1)]},
            {"keys": [("farm_id", 1)]}
        ]
    },
    "farmer_profiles": {
        "description": "Farmer information and preferences",
        "indexes": [
            {"keys": [("farmer_id", 1)], "unique": True},
            {"keys": [("email", 1)], "unique": True}
        ]
    },
    "weather_stations": {
        "description": "Weather station locations",
        "indexes": [
            {"keys": [("station_id", 1)], "unique": True},
            {"keys": [("location", "2dsphere")]}
        ]
    }
}

# =============================================================================
# MongoDB Ingestor Class
# =============================================================================

class MongoDBIngestor:
    """Handles MongoDB connection and data ingestion."""
    
    def __init__(self, uri: str = MONGODB_URI, database: str = DATABASE):
        self.uri = uri
        self.database_name = database
        self.client = None
        self.db = None
        
    def connect(self):
        """Establish connection to MongoDB."""
        print(f"Connecting to MongoDB at {self.uri}...")
        # from pymongo import MongoClient
        # self.client = MongoClient(self.uri)
        # self.db = self.client[self.database_name]
        print(f"  Connected to database: {self.database_name} (simulated)")
        return True
    
    def create_indexes(self):
        """Create indexes for all collections."""
        print("\nCreating indexes...")
        
        for collection_name, schema in COLLECTION_SCHEMAS.items():
            print(f"  Collection: {collection_name}")
            indexes = schema.get("indexes", [])
            
            for idx in indexes:
                keys = idx["keys"]
                unique = idx.get("unique", False)
                key_str = ", ".join([f"{k[0]}:{k[1]}" for k in keys])
                unique_str = " (unique)" if unique else ""
                print(f"    - Index: [{key_str}]{unique_str}")
        
        print("  Indexes created successfully")
    
    def ingest_farms(self, farms: List[Dict]) -> int:
        """Ingest farm documents."""
        print(f"\nIngesting {len(farms)} farms...")
        print(f"  Ingested {len(farms)} farms")
        return len(farms)
    
    def ingest_fields(self, fields: List[Dict]) -> int:
        """Ingest field documents with geospatial data."""
        print(f"\nIngesting {len(fields)} fields...")
        print(f"  Ingested {len(fields)} fields")
        return len(fields)
    
    def ingest_treatment_events(self, events: List[Dict]) -> int:
        """Ingest treatment event documents."""
        print(f"\nIngesting {len(events)} treatment events...")
        print(f"  Ingested {len(events)} treatment events")
        return len(events)
    
    def ingest_grazing_events(self, events: List[Dict]) -> int:
        """Ingest grazing event documents."""
        print(f"\nIngesting {len(events)} grazing events...")
        print(f"  Ingested {len(events)} grazing events")
        return len(events)
    
    def ingest_farmer_profiles(self, profiles: List[Dict]) -> int:
        """Ingest farmer profile documents."""
        print(f"\nIngesting {len(profiles)} farmer profiles...")
        print(f"  Ingested {len(profiles)} farmer profiles")
        return len(profiles)
    
    def ingest_weather_stations(self, stations: List[Dict]) -> int:
        """Ingest weather station documents."""
        print(f"\nIngesting {len(stations)} weather stations...")
        print(f"  Ingested {len(stations)} weather stations")
        return len(stations)
    
    def close(self):
        """Close MongoDB connection."""
        print("\nClosing MongoDB connection...")
        print("  Connection closed")

# =============================================================================
# Sample Queries
# =============================================================================

SAMPLE_QUERIES = {
    "find_field_by_id": """
        // Find a specific field
        db.fields.findOne({ "field_id": "field_001" })
    """,
    
    "fields_with_low_ndvi": """
        // Find fields with NDVI below threshold
        db.fields.find({
            "latest_metrics.ndvi": { $lt: 0.4 }
        }).project({
            field_id: 1,
            name: 1,
            "latest_metrics.ndvi": 1,
            soil_type: 1
        })
    """,
    
    "geo_near_weather_station": """
        // Find fields within 5km of a weather station
        db.fields.aggregate([
            {
                $geoNear: {
                    near: {
                        type: "Point",
                        coordinates: [-89.4012, 43.0731]
                    },
                    distanceField: "distance_m",
                    maxDistance: 5000,
                    spherical: true
                }
            },
            {
                $project: {
                    field_id: 1,
                    name: 1,
                    distance_m: 1,
                    soil_type: 1
                }
            }
        ])
    """,
    
    "at_risk_fields": """
        // Find fields at risk: low NDVI + low moisture + steep slope
        db.fields.find({
            $and: [
                { "latest_metrics.ndvi": { $lt: 0.5 } },
                { "latest_metrics.soil_moisture": { $lt: 20 } },
                { "terrain.slope_pct": { $gt: 8 } }
            ]
        }).project({
            field_id: 1,
            name: 1,
            farm_id: 1,
            "latest_metrics": 1,
            "terrain.slope_pct": 1
        })
    """,
    
    "treatment_history": """
        // Get treatment history for a field
        db.treatment_events.find({
            "field_id": "field_001"
        }).sort({ "applied_date": -1 }).limit(10)
    """,
    
    "aggregate_treatments_by_type": """
        // Count treatments by type for a farm
        db.treatment_events.aggregate([
            { $match: { "farm_id": "farm_001" } },
            { $group: {
                _id: "$treatment_type",
                count: { $sum: 1 },
                total_cost: { $sum: "$cost_usd" }
            }},
            { $sort: { count: -1 } }
        ])
    """,
    
    "fields_by_soil_type_summary": """
        // Summary statistics by soil type
        db.fields.aggregate([
            { $group: {
                _id: "$soil_type",
                count: { $sum: 1 },
                avg_area: { $avg: "$area_ha" },
                avg_ndvi: { $avg: "$latest_metrics.ndvi" },
                avg_moisture: { $avg: "$latest_metrics.soil_moisture" }
            }},
            { $sort: { count: -1 } }
        ])
    """
}

# =============================================================================
# Main Function
# =============================================================================

def main():
    """Main ingestion workflow."""
    print("="*60)
    print("MONGODB INGESTION - Pasture Management System")
    print("="*60)
    
    required_files = [
        "farms.json", "fields.json", "treatment_events.json",
        "grazing_events.json", "farmer_profiles.json", "weather_stations.json"
    ]
    
    missing_files = [f for f in required_files if not os.path.exists(os.path.join(DATA_DIR, f))]
    
    if missing_files:
        print(f"\nMissing data files. Run data_generator.py first.")
        return
    
    data = {}
    for filename in required_files:
        filepath = os.path.join(DATA_DIR, filename)
        print(f"Loading {filepath}...")
        with open(filepath, 'r') as f:
            data[filename.replace('.json', '')] = json.load(f)
    
    ingestor = MongoDBIngestor()
    
    try:
        ingestor.connect()
        ingestor.create_indexes()
        ingestor.ingest_farms(data['farms'])
        ingestor.ingest_fields(data['fields'])
        ingestor.ingest_treatment_events(data['treatment_events'])
        ingestor.ingest_grazing_events(data['grazing_events'])
        ingestor.ingest_farmer_profiles(data['farmer_profiles'])
        ingestor.ingest_weather_stations(data['weather_stations'])
        
        print("\n" + "="*60)
        print("SAMPLE MONGODB QUERIES")
        print("="*60)
        for name, query in SAMPLE_QUERIES.items():
            print(f"\n--- {name} ---")
            print(query.strip())
        
    finally:
        ingestor.close()
    
    print("\n" + "="*60)
    print("INGESTION COMPLETE")
    print("="*60)

if __name__ == "__main__":
    main()

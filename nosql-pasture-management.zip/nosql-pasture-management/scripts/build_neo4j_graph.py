#!/usr/bin/env python3
"""
Neo4j Graph Builder for Pasture Management System

Builds the knowledge graph for relationships and advisory rules.
Demonstrates:
- Node creation with properties
- Relationship modeling
- Cypher query patterns
- Advisory rule matching
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any

# =============================================================================
# Configuration
# =============================================================================

NEO4J_URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "password123")
DATA_DIR = os.getenv("DATA_DIR", "data")

# =============================================================================
# Cypher Templates
# =============================================================================

# Constraint and Index Creation
CONSTRAINTS = [
    "CREATE CONSTRAINT farm_id_unique IF NOT EXISTS FOR (f:Farm) REQUIRE f.farm_id IS UNIQUE",
    "CREATE CONSTRAINT field_id_unique IF NOT EXISTS FOR (f:Field) REQUIRE f.field_id IS UNIQUE",
    "CREATE CONSTRAINT farmer_id_unique IF NOT EXISTS FOR (f:Farmer) REQUIRE f.farmer_id IS UNIQUE",
    "CREATE CONSTRAINT sensor_id_unique IF NOT EXISTS FOR (s:Sensor) REQUIRE s.sensor_id IS UNIQUE",
    "CREATE CONSTRAINT species_id_unique IF NOT EXISTS FOR (s:CropSpecies) REQUIRE s.species_id IS UNIQUE",
    "CREATE CONSTRAINT rule_id_unique IF NOT EXISTS FOR (r:AdvisoryRule) REQUIRE r.rule_id IS UNIQUE",
    "CREATE CONSTRAINT station_id_unique IF NOT EXISTS FOR (w:WeatherStation) REQUIRE w.station_id IS UNIQUE",
]

INDEXES = [
    "CREATE INDEX field_soil_type IF NOT EXISTS FOR (f:Field) ON (f.soil_type)",
    "CREATE INDEX field_risk_level IF NOT EXISTS FOR (f:Field) ON (f.current_risk_level)",
    "CREATE INDEX treatment_type IF NOT EXISTS FOR (t:Treatment) ON (t.type)",
    "CREATE INDEX rule_priority IF NOT EXISTS FOR (r:AdvisoryRule) ON (r.priority)",
]

# Node Creation Templates
CREATE_FARM = """
MERGE (f:Farm {farm_id: $farm_id})
SET f.name = $name,
    f.region = $region,
    f.total_area_ha = $total_area_ha,
    f.latitude = $latitude,
    f.longitude = $longitude
RETURN f
"""

CREATE_FARMER = """
MERGE (fr:Farmer {farmer_id: $farmer_id})
SET fr.name = $name,
    fr.email = $email,
    fr.phone = $phone
RETURN fr
"""

CREATE_FIELD = """
MERGE (f:Field {field_id: $field_id})
SET f.name = $name,
    f.area_ha = $area_ha,
    f.soil_type = $soil_type,
    f.slope_pct = $slope_pct,
    f.elevation_m = $elevation_m,
    f.aspect = $aspect,
    f.current_risk_level = $risk_level
RETURN f
"""

CREATE_SENSOR = """
MERGE (s:Sensor {sensor_id: $sensor_id})
SET s.type = $type
RETURN s
"""

CREATE_SPECIES = """
MERGE (s:CropSpecies {species_id: $species_id})
SET s.name = $name,
    s.scientific_name = $scientific_name,
    s.drought_tolerance = $drought_tolerance
RETURN s
"""

CREATE_ADVISORY_RULE = """
MERGE (r:AdvisoryRule {rule_id: $rule_id})
SET r.name = $name,
    r.description = $description,
    r.trigger_condition = $trigger_condition,
    r.priority = $priority,
    r.action = $action,
    r.expected_outcome = $expected_outcome
RETURN r
"""

CREATE_TREATMENT = """
CREATE (t:Treatment {
    treatment_id: $treatment_id,
    type: $type,
    product: $product,
    rate: $rate,
    unit: $unit,
    applied_date: date($applied_date)
})
RETURN t
"""

CREATE_WEATHER_STATION = """
MERGE (w:WeatherStation {station_id: $station_id})
SET w.name = $name,
    w.latitude = $latitude,
    w.longitude = $longitude,
    w.elevation_m = $elevation_m
RETURN w
"""

CREATE_RISK_EVENT = """
CREATE (e:RiskEvent {
    event_id: $event_id,
    event_type: $event_type,
    detected_at: datetime($detected_at),
    metric_value: $metric_value,
    threshold_value: $threshold_value,
    severity: $severity,
    resolved: false
})
RETURN e
"""

# Relationship Templates
LINK_FARM_FARMER = """
MATCH (f:Farm {farm_id: $farm_id})
MATCH (fr:Farmer {farmer_id: $farmer_id})
MERGE (f)-[:OWNED_BY]->(fr)
MERGE (fr)-[:MANAGES]->(f)
"""

LINK_FIELD_FARM = """
MATCH (field:Field {field_id: $field_id})
MATCH (farm:Farm {farm_id: $farm_id})
MERGE (farm)-[:CONTAINS]->(field)
MERGE (field)-[:BELONGS_TO]->(farm)
"""

LINK_FIELD_SENSOR = """
MATCH (field:Field {field_id: $field_id})
MATCH (sensor:Sensor {sensor_id: $sensor_id})
MERGE (field)-[:HAS_SENSOR]->(sensor)
MERGE (sensor)-[:MONITORS]->(field)
"""

LINK_FIELD_SPECIES = """
MATCH (field:Field {field_id: $field_id})
MATCH (species:CropSpecies {species_id: $species_id})
MERGE (field)-[:GROWS {coverage_pct: $coverage_pct}]->(species)
"""

LINK_RULE_SPECIES = """
MATCH (rule:AdvisoryRule {rule_id: $rule_id})
MATCH (species:CropSpecies {species_id: $species_id})
MERGE (rule)-[:APPLIES_TO]->(species)
"""

LINK_FIELD_TREATMENT = """
MATCH (field:Field {field_id: $field_id})
MATCH (treatment:Treatment {treatment_id: $treatment_id})
MERGE (field)-[:RECEIVED_TREATMENT]->(treatment)
MERGE (treatment)-[:APPLIED_TO]->(field)
"""

LINK_FIELD_RISK_EVENT = """
MATCH (field:Field {field_id: $field_id})
MATCH (event:RiskEvent {event_id: $event_id})
MERGE (field)-[:HAS_RISK_EVENT]->(event)
"""

LINK_ADJACENT_FIELDS = """
MATCH (f1:Field {field_id: $field_id_1})
MATCH (f2:Field {field_id: $field_id_2})
MERGE (f1)-[:ADJACENT_TO]->(f2)
MERGE (f2)-[:ADJACENT_TO]->(f1)
"""

# =============================================================================
# Neo4j Graph Builder Class
# =============================================================================

class Neo4jGraphBuilder:
    """
    Builds and manages the Neo4j knowledge graph.
    
    Node types: Farm, Farmer, Field, Sensor, CropSpecies, Treatment, AdvisoryRule, RiskEvent
    """
    
    def __init__(self, uri: str = NEO4J_URI, user: str = NEO4J_USER, password: str = NEO4J_PASSWORD):
        self.uri = uri
        self.user = user
        self.password = password
        self.driver = None
        
    def connect(self):
        """Establish connection to Neo4j."""
        print(f"Connecting to Neo4j at {self.uri}...")
        # from neo4j import GraphDatabase
        # self.driver = GraphDatabase.driver(self.uri, auth=(self.user, self.password))
        # self.driver.verify_connectivity()
        print("  Connected successfully (simulated)")
        return True
    
    def create_constraints_and_indexes(self):
        """Create uniqueness constraints and indexes."""
        print("\nCreating constraints and indexes...")
        
        for constraint in CONSTRAINTS:
            constraint_name = constraint.split("CONSTRAINT ")[1].split(" IF")[0]
            print(f"  Constraint: {constraint_name}")
            # with self.driver.session() as session:
            #     session.run(constraint)
        
        for index in INDEXES:
            index_name = index.split("INDEX ")[1].split(" IF")[0]
            print(f"  Index: {index_name}")
            # with self.driver.session() as session:
            #     session.run(index)
        
        print("  Constraints and indexes created")
    
    def build_farm_nodes(self, farms: List[Dict]):
        """Create Farm and Farmer nodes with ownership relationships."""
        print(f"\nCreating {len(farms)} Farm and Farmer nodes...")
        
        for farm in farms:
            coords = farm['location']['center']['coordinates']
            
            params = {
                'farm_id': farm['farm_id'],
                'name': farm['name'],
                'region': farm['location']['region'],
                'total_area_ha': farm['total_area_ha'],
                'latitude': coords[1],
                'longitude': coords[0]
            }
            print(f"  CREATE Farm: {farm['farm_id']} - {farm['name']}")
            # with self.driver.session() as session:
            #     session.run(CREATE_FARM, params)
            
            # Create farmer
            owner = farm['owner']
            farmer_params = {
                'farmer_id': owner['farmer_id'],
                'name': owner['name'],
                'email': owner['contact']['email'],
                'phone': owner['contact']['phone']
            }
            print(f"  CREATE Farmer: {owner['farmer_id']} - {owner['name']}")
            # with self.driver.session() as session:
            #     session.run(CREATE_FARMER, farmer_params)
            
            # Link farm to farmer
            print(f"  LINK (Farm)-[:OWNED_BY]->(Farmer)")
            # with self.driver.session() as session:
            #     session.run(LINK_FARM_FARMER, {
            #         'farm_id': farm['farm_id'],
            #         'farmer_id': owner['farmer_id']
            #     })
    
    def build_field_nodes(self, fields: List[Dict]):
        """Create Field nodes with all relationships."""
        print(f"\nCreating {len(fields)} Field nodes...")
        
        for field in fields:
            terrain = field.get('terrain', {})
            
            params = {
                'field_id': field['field_id'],
                'name': field['name'],
                'area_ha': field['area_ha'],
                'soil_type': field['soil_type'],
                'slope_pct': terrain.get('slope_pct', 0),
                'elevation_m': terrain.get('elevation_m', 0),
                'aspect': terrain.get('aspect', 'flat'),
                'risk_level': 'low'
            }
            print(f"  CREATE Field: {field['field_id']} - {field['name']}")
            # with self.driver.session() as session:
            #     session.run(CREATE_FIELD, params)
            
            # Link to farm
            # with self.driver.session() as session:
            #     session.run(LINK_FIELD_FARM, {
            #         'field_id': field['field_id'],
            #         'farm_id': field['farm_id']
            #     })
            
            # Create and link sensors
            for sensor_id in field.get('sensors', []):
                sensor_type = sensor_id.split('_')[1] if '_' in sensor_id else 'unknown'
                # with self.driver.session() as session:
                #     session.run(CREATE_SENSOR, {'sensor_id': sensor_id, 'type': sensor_type})
                #     session.run(LINK_FIELD_SENSOR, {
                #         'field_id': field['field_id'],
                #         'sensor_id': sensor_id
                #     })
            
            # Link to species
            for species in field.get('current_species', []):
                # with self.driver.session() as session:
                #     session.run(LINK_FIELD_SPECIES, {
                #         'field_id': field['field_id'],
                #         'species_id': species['species_id'],
                #         'coverage_pct': species['coverage_pct']
                #     })
                pass
    
    def build_species_nodes(self):
        """Create CropSpecies nodes."""
        species_data = [
            {"id": "sp_001", "name": "Perennial Ryegrass", "scientific": "Lolium perenne", "drought_tol": "medium"},
            {"id": "sp_002", "name": "White Clover", "scientific": "Trifolium repens", "drought_tol": "low"},
            {"id": "sp_003", "name": "Timothy", "scientific": "Phleum pratense", "drought_tol": "medium"},
            {"id": "sp_004", "name": "Kentucky Bluegrass", "scientific": "Poa pratensis", "drought_tol": "low"},
            {"id": "sp_005", "name": "Tall Fescue", "scientific": "Festuca arundinacea", "drought_tol": "high"},
            {"id": "sp_006", "name": "Orchardgrass", "scientific": "Dactylis glomerata", "drought_tol": "medium"},
        ]
        
        print(f"\nCreating {len(species_data)} CropSpecies nodes...")
        
        for species in species_data:
            params = {
                'species_id': species['id'],
                'name': species['name'],
                'scientific_name': species['scientific'],
                'drought_tolerance': species['drought_tol']
            }
            print(f"  CREATE CropSpecies: {species['name']}")
            # with self.driver.session() as session:
            #     session.run(CREATE_SPECIES, params)
    
    def build_advisory_rules(self, rules: List[Dict]):
        """Create AdvisoryRule nodes and link to species."""
        print(f"\nCreating {len(rules)} AdvisoryRule nodes...")
        
        for rule in rules:
            params = {
                'rule_id': rule['rule_id'],
                'name': rule['name'],
                'description': rule['description'],
                'trigger_condition': rule['trigger_condition'],
                'priority': rule['priority'],
                'action': rule['action'],
                'expected_outcome': rule['expected_outcome']
            }
            print(f"  CREATE AdvisoryRule: {rule['name']}")
            # with self.driver.session() as session:
            #     session.run(CREATE_ADVISORY_RULE, params)
            
            # Link to applicable species
            for species_id in rule.get('applies_to_species', []):
                if species_id != 'all':
                    # with self.driver.session() as session:
                    #     session.run(LINK_RULE_SPECIES, {
                    #         'rule_id': rule['rule_id'],
                    #         'species_id': species_id
                    #     })
                    pass
    
    def build_treatment_history(self, events: List[Dict]):
        """Create Treatment nodes from historical events."""
        print(f"\nCreating Treatment nodes from {len(events)} events...")
        
        for event in events[:20]:  # Limit for demo
            applied_date = event['applied_date'][:10]  # Extract date part
            
            params = {
                'treatment_id': event['event_id'],
                'type': event['treatment_type'],
                'product': event['treatment_details']['product'],
                'rate': event['treatment_details']['rate'],
                'unit': event['treatment_details']['unit'],
                'applied_date': applied_date
            }
            # with self.driver.session() as session:
            #     session.run(CREATE_TREATMENT, params)
            #     session.run(LINK_FIELD_TREATMENT, {
            #         'field_id': event['field_id'],
            #         'treatment_id': event['event_id']
            #     })
        
        print(f"  Created {min(20, len(events))} Treatment nodes")
    
    def build_weather_stations(self, stations: List[Dict]):
        """Create WeatherStation nodes."""
        print(f"\nCreating {len(stations)} WeatherStation nodes...")
        
        for station in stations:
            params = {
                'station_id': station['station_id'],
                'name': station['name'],
                'latitude': station['latitude'],
                'longitude': station['longitude'],
                'elevation_m': station.get('elevation_m', 0)
            }
            print(f"  CREATE WeatherStation: {station['name']}")
            # with self.driver.session() as session:
            #     session.run(CREATE_WEATHER_STATION, params)
    
    def close(self):
        """Close Neo4j connection."""
        print("\nClosing Neo4j connection...")
        # if self.driver:
        #     self.driver.close()
        print("  Connection closed")


# =============================================================================
# Sample Cypher Queries
# =============================================================================

SAMPLE_QUERIES = """
# =============================================================================
# NEO4J CYPHER QUERIES REFERENCE
# =============================================================================

# --- Find all fields for a specific farmer ---
MATCH (farmer:Farmer {name: "John Smith"})-[:MANAGES]->(farm:Farm)-[:CONTAINS]->(field:Field)
RETURN farmer.name, farm.name, field.field_id, field.name, field.soil_type

# --- Find fields with specific crop species ---
MATCH (field:Field)-[:GROWS]->(species:CropSpecies {name: "Perennial Ryegrass"})
RETURN field.field_id, field.name, field.soil_type

# --- Get advisory rules applicable to a field's species ---
MATCH (field:Field {field_id: "field_001"})-[:GROWS]->(species:CropSpecies)
MATCH (rule:AdvisoryRule)-[:APPLIES_TO]->(species)
RETURN DISTINCT rule.name, rule.description, rule.priority, rule.action
ORDER BY rule.priority

# --- Find fields that share the same farmer and had same treatment last year ---
MATCH (farmer:Farmer)-[:MANAGES]->(farm:Farm)-[:CONTAINS]->(f1:Field)
MATCH (f1)-[:RECEIVED_TREATMENT]->(t1:Treatment)
MATCH (farmer)-[:MANAGES]->(farm2:Farm)-[:CONTAINS]->(f2:Field)
MATCH (f2)-[:RECEIVED_TREATMENT]->(t2:Treatment)
WHERE f1 <> f2 
  AND t1.type = t2.type
  AND t1.applied_date > date() - duration({months: 12})
  AND t2.applied_date > date() - duration({months: 12})
RETURN farmer.name, f1.field_id, f2.field_id, t1.type, t1.applied_date

# --- Find high-risk fields with their species and applicable rules ---
MATCH (field:Field {current_risk_level: "high"})-[:GROWS]->(species:CropSpecies)
OPTIONAL MATCH (rule:AdvisoryRule)-[:APPLIES_TO]->(species)
RETURN field.field_id, field.name, 
       collect(DISTINCT species.name) as species,
       collect(DISTINCT rule.name) as applicable_rules

# --- Get treatment history for a field ---
MATCH (field:Field {field_id: "field_001"})-[:RECEIVED_TREATMENT]->(treatment:Treatment)
RETURN treatment.type, treatment.product, treatment.rate, treatment.unit, treatment.applied_date
ORDER BY treatment.applied_date DESC
LIMIT 10

# --- Find adjacent fields with different risk levels ---
MATCH (f1:Field)-[:ADJACENT_TO]->(f2:Field)
WHERE f1.current_risk_level <> f2.current_risk_level
RETURN f1.field_id, f1.current_risk_level, f2.field_id, f2.current_risk_level

# --- Count fields by soil type and risk level ---
MATCH (field:Field)
RETURN field.soil_type, field.current_risk_level, count(*) as field_count
ORDER BY field.soil_type, field.current_risk_level

# --- Find drought-tolerant species for fields on steep slopes ---
MATCH (field:Field)
WHERE field.slope_pct > 10
MATCH (species:CropSpecies {drought_tolerance: "high"})
WHERE NOT (field)-[:GROWS]->(species)
RETURN field.field_id, field.slope_pct, species.name as recommended_species

# --- Get sensors monitoring at-risk fields ---
MATCH (field:Field)-[:HAS_SENSOR]->(sensor:Sensor)
WHERE field.current_risk_level IN ['high', 'critical']
RETURN field.field_id, field.current_risk_level, collect(sensor.sensor_id) as sensors

# --- Path: Farmer -> Farm -> Field -> Species -> AdvisoryRule ---
MATCH path = (farmer:Farmer)-[:MANAGES]->(farm:Farm)-[:CONTAINS]->(field:Field)
             -[:GROWS]->(species:CropSpecies)<-[:APPLIES_TO]-(rule:AdvisoryRule)
WHERE farmer.farmer_id = "farmer_001"
RETURN path

# --- Create risk event and link to field ---
MATCH (field:Field {field_id: "field_001"})
CREATE (event:RiskEvent {
    event_id: "risk_" + toString(timestamp()),
    event_type: "moisture_critical",
    detected_at: datetime(),
    metric_value: 8.5,
    threshold_value: 10.0,
    severity: "critical",
    resolved: false
})
MERGE (field)-[:HAS_RISK_EVENT]->(event)
RETURN event

# --- Find unresolved risk events with recommended actions ---
MATCH (field:Field)-[:HAS_RISK_EVENT]->(event:RiskEvent {resolved: false})
MATCH (field)-[:GROWS]->(species:CropSpecies)
OPTIONAL MATCH (rule:AdvisoryRule)-[:APPLIES_TO]->(species)
WHERE rule.trigger_condition CONTAINS event.event_type
RETURN field.field_id, event.event_type, event.severity, 
       rule.name as recommended_rule, rule.action
ORDER BY event.severity DESC

# --- Update field risk level based on events ---
MATCH (field:Field {field_id: "field_001"})
SET field.current_risk_level = "high"
RETURN field
"""


# =============================================================================
# Main Function
# =============================================================================

def main():
    """Main graph building workflow."""
    print("="*60)
    print("NEO4J GRAPH BUILDER - Pasture Management System")
    print("="*60)
    
    # Load data
    required_files = ["farms.json", "fields.json", "treatment_events.json", 
                      "advisory_rules.json", "weather_stations.json"]
    
    missing_files = [f for f in required_files if not os.path.exists(os.path.join(DATA_DIR, f))]
    
    if missing_files:
        print(f"\nMissing data files. Run data_generator.py first.")
        return
    
    data = {}
    for filename in required_files:
        filepath = os.path.join(DATA_DIR, filename)
        print(f"Loading {filepath}...")
        with open(filepath, 'r') as f:
            data[filename.replace('.json', '')] = json.load(f)
    
    # Initialize Neo4j connection
    builder = Neo4jGraphBuilder()
    
    try:
        builder.connect()
        builder.create_constraints_and_indexes()
        
        # Build graph
        builder.build_species_nodes()
        builder.build_farm_nodes(data['farms'])
        builder.build_field_nodes(data['fields'])
        builder.build_advisory_rules(data['advisory_rules'])
        builder.build_treatment_history(data['treatment_events'])
        builder.build_weather_stations(data['weather_stations'])
        
        # Print sample queries
        print("\n" + "="*60)
        print("CYPHER QUERIES REFERENCE")
        print("="*60)
        print(SAMPLE_QUERIES)
        
    finally:
        builder.close()
    
    print("\n" + "="*60)
    print("GRAPH BUILD COMPLETE")
    print("="*60)


if __name__ == "__main__":
    main()

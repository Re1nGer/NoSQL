#!/usr/bin/env python3
"""
Cassandra Ingestion Script for Pasture Management System

Ingests time-series sensor data into Apache Cassandra.
Demonstrates:
- Keyspace and table creation
- Batch inserts for high-throughput
- Time-series data modeling
- TTL and compaction strategies
"""

import json
import os
from datetime import datetime
from typing import List, Dict

# For demonstration, using pseudo-code structure
# In production, uncomment cassandra-driver imports

# from cassandra.cluster import Cluster
# from cassandra.auth import PlainTextAuthProvider
# from cassandra.query import BatchStatement, SimpleStatement
# from cassandra import ConsistencyLevel

# =============================================================================
# Configuration
# =============================================================================

CASSANDRA_HOST = os.getenv("CASSANDRA_HOST", "localhost")
CASSANDRA_PORT = int(os.getenv("CASSANDRA_PORT", "9042"))
KEYSPACE = os.getenv("CASSANDRA_KEYSPACE", "pasture_mgmt")

DATA_DIR = os.getenv("DATA_DIR", "data")

# =============================================================================
# Schema Definitions
# =============================================================================

KEYSPACE_CQL = """
CREATE KEYSPACE IF NOT EXISTS pasture_mgmt
WITH replication = {
    'class': 'SimpleStrategy',
    'replication_factor': 1
}
AND durable_writes = true;
"""

TABLES_CQL = [
    # Main sensor data table - partitioned by field, clustered by time
    """
    CREATE TABLE IF NOT EXISTS pasture_mgmt.sensor_data_by_field (
        field_id        TEXT,
        sensor_ts       TIMESTAMP,
        sensor_id       TEXT,
        metric_type     TEXT,
        metric_value    DOUBLE,
        quality_flag    INT,
        unit            TEXT,
        PRIMARY KEY ((field_id), sensor_ts, sensor_id, metric_type)
    ) WITH CLUSTERING ORDER BY (sensor_ts DESC, sensor_id ASC, metric_type ASC)
      AND compaction = {
          'class': 'TimeWindowCompactionStrategy',
          'compaction_window_size': 1,
          'compaction_window_unit': 'DAYS'
      }
      AND default_time_to_live = 31536000
      AND gc_grace_seconds = 864000;
    """,
    
    # Daily aggregates table for faster analytical queries
    """
    CREATE TABLE IF NOT EXISTS pasture_mgmt.daily_aggregates_by_field (
        field_id        TEXT,
        date            DATE,
        metric_type     TEXT,
        min_value       DOUBLE,
        max_value       DOUBLE,
        avg_value       DOUBLE,
        sum_value       DOUBLE,
        count           INT,
        PRIMARY KEY ((field_id, metric_type), date)
    ) WITH CLUSTERING ORDER BY (date DESC)
      AND compaction = {
          'class': 'LeveledCompactionStrategy'
      }
      AND default_time_to_live = 94608000;
    """,
    
    # Farm-level view for cross-field queries (hot data only)
    """
    CREATE TABLE IF NOT EXISTS pasture_mgmt.sensor_data_by_farm (
        farm_id         TEXT,
        sensor_ts       TIMESTAMP,
        field_id        TEXT,
        sensor_id       TEXT,
        metric_type     TEXT,
        metric_value    DOUBLE,
        PRIMARY KEY ((farm_id), sensor_ts, field_id)
    ) WITH CLUSTERING ORDER BY (sensor_ts DESC, field_id ASC)
      AND default_time_to_live = 604800;
    """,
    
    # Latest reading per field (materialized view alternative)
    """
    CREATE TABLE IF NOT EXISTS pasture_mgmt.latest_metrics_by_field (
        field_id        TEXT,
        metric_type     TEXT,
        metric_value    DOUBLE,
        sensor_ts       TIMESTAMP,
        sensor_id       TEXT,
        PRIMARY KEY (field_id, metric_type)
    );
    """
]

# Index for metric type filtering (use sparingly in Cassandra)
INDEX_CQL = """
CREATE INDEX IF NOT EXISTS idx_metric_type 
ON pasture_mgmt.sensor_data_by_field (metric_type);
"""

# =============================================================================
# Insert Statements
# =============================================================================

INSERT_SENSOR_DATA = """
INSERT INTO pasture_mgmt.sensor_data_by_field 
    (field_id, sensor_ts, sensor_id, metric_type, metric_value, quality_flag, unit)
VALUES (?, ?, ?, ?, ?, ?, ?);
"""

INSERT_FARM_DATA = """
INSERT INTO pasture_mgmt.sensor_data_by_farm
    (farm_id, sensor_ts, field_id, sensor_id, metric_type, metric_value)
VALUES (?, ?, ?, ?, ?, ?);
"""

INSERT_LATEST = """
INSERT INTO pasture_mgmt.latest_metrics_by_field
    (field_id, metric_type, metric_value, sensor_ts, sensor_id)
VALUES (?, ?, ?, ?, ?);
"""

# =============================================================================
# Cassandra Connection Class (Pseudo-implementation)
# =============================================================================

class CassandraIngestor:
    """
    Handles Cassandra connection and data ingestion.
    
    In production, this would use the cassandra-driver.
    This implementation shows the structure and can be run as a demonstration.
    """
    
    def __init__(self, host: str = CASSANDRA_HOST, port: int = CASSANDRA_PORT):
        self.host = host
        self.port = port
        self.session = None
        self.cluster = None
        self.prepared_statements = {}
        
    def connect(self):
        """Establish connection to Cassandra cluster."""
        print(f"Connecting to Cassandra at {self.host}:{self.port}...")
        
        # Production code:
        # self.cluster = Cluster([self.host], port=self.port)
        # self.session = self.cluster.connect()
        
        print("  Connected successfully (simulated)")
        return True
    
    def create_schema(self):
        """Create keyspace and tables if they don't exist."""
        print("\nCreating schema...")
        
        # Create keyspace
        print("  Creating keyspace: pasture_mgmt")
        # self.session.execute(KEYSPACE_CQL)
        
        # Create tables
        for i, table_cql in enumerate(TABLES_CQL):
            table_name = table_cql.split("CREATE TABLE IF NOT EXISTS ")[1].split("(")[0].strip()
            print(f"  Creating table: {table_name}")
            # self.session.execute(table_cql)
        
        # Create index
        print("  Creating index: idx_metric_type")
        # self.session.execute(INDEX_CQL)
        
        print("  Schema created successfully")
    
    def prepare_statements(self):
        """Prepare CQL statements for efficient batch inserts."""
        print("\nPreparing statements...")
        
        # Production code:
        # self.prepared_statements['sensor_data'] = self.session.prepare(INSERT_SENSOR_DATA)
        # self.prepared_statements['farm_data'] = self.session.prepare(INSERT_FARM_DATA)
        # self.prepared_statements['latest'] = self.session.prepare(INSERT_LATEST)
        
        self.prepared_statements = {
            'sensor_data': INSERT_SENSOR_DATA,
            'farm_data': INSERT_FARM_DATA,
            'latest': INSERT_LATEST
        }
        print("  Statements prepared")
    
    def ingest_sensor_data(self, sensor_data: List[Dict], batch_size: int = 100):
        """
        Ingest sensor readings into Cassandra tables.
        
        Uses batching for efficient inserts.
        Writes to multiple tables for different query patterns.
        """
        print(f"\nIngesting {len(sensor_data):,} sensor readings...")
        
        total = len(sensor_data)
        batches = 0
        
        # Track latest readings per field/metric for the latest_metrics table
        latest_readings = {}
        
        for i in range(0, total, batch_size):
            batch = sensor_data[i:i + batch_size]
            
            # Production code would use BatchStatement:
            # batch_stmt = BatchStatement(consistency_level=ConsistencyLevel.LOCAL_QUORUM)
            
            for reading in batch:
                # Parse timestamp
                ts = datetime.fromisoformat(reading['sensor_ts'].replace('Z', '+00:00'))
                
                # Insert into sensor_data_by_field
                # batch_stmt.add(self.prepared_statements['sensor_data'], (
                #     reading['field_id'],
                #     ts,
                #     reading['sensor_id'],
                #     reading['metric_type'],
                #     reading['metric_value'],
                #     reading['quality_flag'],
                #     reading['unit']
                # ))
                
                # Insert into sensor_data_by_farm (for cross-field queries)
                # batch_stmt.add(self.prepared_statements['farm_data'], (
                #     reading['farm_id'],
                #     ts,
                #     reading['field_id'],
                #     reading['sensor_id'],
                #     reading['metric_type'],
                #     reading['metric_value']
                # ))
                
                # Track latest reading
                key = (reading['field_id'], reading['metric_type'])
                if key not in latest_readings or ts > datetime.fromisoformat(
                    latest_readings[key]['sensor_ts'].replace('Z', '+00:00')):
                    latest_readings[key] = reading
            
            # Execute batch
            # self.session.execute(batch_stmt)
            
            batches += 1
            if batches % 100 == 0:
                print(f"  Processed {min(i + batch_size, total):,}/{total:,} readings...")
        
        # Insert latest readings
        print(f"\nUpdating latest metrics for {len(latest_readings)} field/metric combinations...")
        for (field_id, metric_type), reading in latest_readings.items():
            ts = datetime.fromisoformat(reading['sensor_ts'].replace('Z', '+00:00'))
            # self.session.execute(self.prepared_statements['latest'], (
            #     field_id,
            #     metric_type,
            #     reading['metric_value'],
            #     ts,
            #     reading['sensor_id']
            # ))
        
        print(f"  Ingestion complete: {total:,} readings in {batches} batches")
        return total
    
    def compute_daily_aggregates(self, sensor_data: List[Dict]):
        """
        Compute and store daily aggregates for faster analytical queries.
        
        In production, this might be done by a scheduled job or Spark.
        """
        print("\nComputing daily aggregates...")
        
        # Group by field_id, date, metric_type
        aggregates = {}
        
        for reading in sensor_data:
            ts = datetime.fromisoformat(reading['sensor_ts'].replace('Z', '+00:00'))
            date_key = ts.date()
            key = (reading['field_id'], date_key, reading['metric_type'])
            
            if key not in aggregates:
                aggregates[key] = {
                    'min': float('inf'),
                    'max': float('-inf'),
                    'sum': 0,
                    'count': 0
                }
            
            value = reading['metric_value']
            agg = aggregates[key]
            agg['min'] = min(agg['min'], value)
            agg['max'] = max(agg['max'], value)
            agg['sum'] += value
            agg['count'] += 1
        
        # Insert aggregates
        insert_agg = """
        INSERT INTO pasture_mgmt.daily_aggregates_by_field
            (field_id, date, metric_type, min_value, max_value, avg_value, sum_value, count)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """
        
        for (field_id, date, metric_type), agg in aggregates.items():
            avg_value = agg['sum'] / agg['count']
            # self.session.execute(insert_agg, (
            #     field_id, date, metric_type,
            #     agg['min'], agg['max'], avg_value, agg['sum'], agg['count']
            # ))
        
        print(f"  Computed {len(aggregates)} daily aggregates")
        return len(aggregates)
    
    def close(self):
        """Close Cassandra connection."""
        print("\nClosing Cassandra connection...")
        # if self.cluster:
        #     self.cluster.shutdown()
        print("  Connection closed")


# =============================================================================
# Sample Queries
# =============================================================================

SAMPLE_QUERIES = {
    "last_24h_by_field": """
        -- Get all sensor readings for a field in the last 24 hours
        SELECT field_id, sensor_ts, sensor_id, metric_type, metric_value
        FROM pasture_mgmt.sensor_data_by_field
        WHERE field_id = 'field_001'
          AND sensor_ts >= '2024-10-14T00:00:00Z'
          AND sensor_ts < '2024-10-15T00:00:00Z'
        ORDER BY sensor_ts DESC;
    """,
    
    "soil_moisture_last_7d": """
        -- Get soil moisture readings for a field over the last 7 days
        SELECT sensor_ts, metric_value
        FROM pasture_mgmt.sensor_data_by_field
        WHERE field_id = 'field_001'
          AND metric_type = 'soil_moisture'
          AND sensor_ts >= '2024-10-08T00:00:00Z'
        ORDER BY sensor_ts DESC;
    """,
    
    "daily_avg_grass_height": """
        -- Get daily average grass height for the last 30 days
        SELECT date, avg_value, min_value, max_value
        FROM pasture_mgmt.daily_aggregates_by_field
        WHERE field_id = 'field_001'
          AND metric_type = 'grass_height'
          AND date >= '2024-09-15'
        ORDER BY date DESC
        LIMIT 30;
    """,
    
    "farm_level_metrics": """
        -- Get recent readings across all fields in a farm
        SELECT field_id, sensor_ts, metric_type, metric_value
        FROM pasture_mgmt.sensor_data_by_farm
        WHERE farm_id = 'farm_001'
          AND sensor_ts >= '2024-10-14T00:00:00Z'
        ORDER BY sensor_ts DESC
        LIMIT 100;
    """,
    
    "latest_metrics": """
        -- Get latest value for each metric type for a field
        SELECT metric_type, metric_value, sensor_ts
        FROM pasture_mgmt.latest_metrics_by_field
        WHERE field_id = 'field_001';
    """
}


# =============================================================================
# Main Function
# =============================================================================

def main():
    """Main ingestion workflow."""
    print("="*60)
    print("CASSANDRA INGESTION - Pasture Management System")
    print("="*60)
    
    # Load sensor data
    data_file = os.path.join(DATA_DIR, "sensor_data.json")
    
    if not os.path.exists(data_file):
        print(f"\nData file not found: {data_file}")
        print("Run data_generator.py first to create sample data.")
        
        # Generate sample data for demonstration
        print("\nGenerating sample data for demonstration...")
        from data_generator import generate_all_data
        generate_all_data(DATA_DIR)
    
    print(f"\nLoading sensor data from {data_file}...")
    with open(data_file, 'r') as f:
        sensor_data = json.load(f)
    print(f"  Loaded {len(sensor_data):,} sensor readings")
    
    # Initialize Cassandra connection
    ingestor = CassandraIngestor()
    
    try:
        # Connect and set up schema
        ingestor.connect()
        ingestor.create_schema()
        ingestor.prepare_statements()
        
        # Ingest data
        ingestor.ingest_sensor_data(sensor_data)
        ingestor.compute_daily_aggregates(sensor_data)
        
        # Print sample queries
        print("\n" + "="*60)
        print("SAMPLE CQL QUERIES")
        print("="*60)
        for name, query in SAMPLE_QUERIES.items():
            print(f"\n--- {name} ---")
            print(query.strip())
        
    finally:
        ingestor.close()
    
    print("\n" + "="*60)
    print("INGESTION COMPLETE")
    print("="*60)


if __name__ == "__main__":
    main()
